A Pen created at CodePen.io. You can find this one at https://codepen.io/MartijnBrands/pen/xGxrRj.

 A simple CSS hover animation inspired by @JeroenVanEerden on Dribbble